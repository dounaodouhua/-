create definer = root@localhost view view_user_role_detail as
select `cms`.`rel_user_role`.`IS_DELETED`       AS `IS_DELETED`,
       `cms`.`rel_user_role`.`ROLE_ID`          AS `ROLE_ID`,
       `cms`.`rel_user_role`.`USER_ID`          AS `USER_ID`,
       `cms`.`rel_user_role`.`CREATE_TIME`      AS `CREATE_TIME`,
       `cms`.`rel_user_role`.`UPDATE_TIME`      AS `UPDATE_TIME`,
       `cms`.`rel_user_role`.`IS_AUDIT`         AS `IS_AUDIT`,
       `cms`.`sys_role`.`NAME`                  AS `ROLE_NAME`,
       `cms`.`sys_role`.`CODE`                  AS `ROLE_CODE`,
       `cms`.`rel_user_role`.`ID`               AS `ID`,
       `cms`.`view_base_user`.`PHONE`           AS `USER_PHONE`,
       `cms`.`view_base_user`.`NAME`            AS `USER_NAME`,
       `cms`.`view_base_user`.`DEPARTMENT_NAME` AS `DEPARTMENT_NAME`
from ((`cms`.`sys_role` join `cms`.`rel_user_role`
       on ((`cms`.`sys_role`.`ID` = `cms`.`rel_user_role`.`ROLE_ID`))) join `cms`.`view_base_user`
      on ((`cms`.`view_base_user`.`ID` = `cms`.`rel_user_role`.`USER_ID`)));

-- comment on column view_user_role_detail.IS_DELETED not supported: 删除标记

-- comment on column view_user_role_detail.CREATE_TIME not supported: 创建时间

-- comment on column view_user_role_detail.UPDATE_TIME not supported: 更新时间

-- comment on column view_user_role_detail.ROLE_NAME not supported: 名称

-- comment on column view_user_role_detail.ROLE_CODE not supported: 编码

-- comment on column view_user_role_detail.ID not supported: 编号

-- comment on column view_user_role_detail.USER_PHONE not supported: 手机号码

-- comment on column view_user_role_detail.USER_NAME not supported: 姓名

