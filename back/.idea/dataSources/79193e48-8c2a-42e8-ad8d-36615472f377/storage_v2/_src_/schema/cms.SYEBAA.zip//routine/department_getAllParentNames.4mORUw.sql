create
    definer = root@localhost function department_getAllParentNames(nodeId int) returns varchar(1000) deterministic
BEGIN
    DECLARE parentList VARCHAR(1000);      # 返回父节点结果集
    DECLARE tempParent INTEGER;      # 临时存放父节点
		DECLARE tempName VARCHAR(50);      # 临时存放父节点		
		
    SET parentList = '';
    SET tempParent = nodeId; 
		SET tempName = '';

		SET @tabName = 'base_department';

		
    WHILE tempParent is not NULL DO        # 循环，用于查询节点上所有的父节点
			IF tempName<>'' THEN
				IF parentList<>'' THEN
					SET parentList = CONCAT(tempName,'/', parentList);  
				ELSE
					SET parentList = tempName;
				END IF;
			END IF;
			SET tempName = (SELECT name FROM base_department where id=tempParent);   # 查询节点上所有父节点				
      SET tempParent = (SELECT parent_id FROM base_department where id=tempParent and the_level>=2);   # 查询节点上所有父节点				
    END WHILE;
    RETURN parentList;       # 将返回结果处理，截取掉结果集前面的逗号
END;

