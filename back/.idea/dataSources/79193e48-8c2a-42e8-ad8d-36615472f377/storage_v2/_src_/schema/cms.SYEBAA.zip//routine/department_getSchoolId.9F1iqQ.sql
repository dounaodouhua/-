create
    definer = root@localhost function department_getSchoolId(nodeId int) returns int deterministic
BEGIN
    DECLARE theLevel INTEGER; 
		DECLARE tempID INTEGER;
		DECLARE parentId INTEGER;
		
		SET tempID = nodeId;
		SET parentId = nodeId;
		SET theLevel = (SELECT the_level FROM base_department where id=tempID);


    WHILE parentId<>-1 and theLevel<>2 DO        # 循环，用于查询节点上所有的父节点
			SET parentId = (SELECT parent_id FROM base_department where id=tempID);   # 查询节点上所有父节点				
      SET theLevel = (SELECT the_level FROM base_department where id=parentId);   # 查询节点上所有父节点
    END WHILE;
		IF theLevel<>2 THEN
			RETURN 0;       # 将返回结果处理，截取掉结果集前面的逗号
		ELSE
			RETURN parentId;
		END IF;
		
END;

