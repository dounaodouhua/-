create definer = root@localhost view view_base_user as
select `cms`.`base_user`.`ADDRESS`                                       AS `ADDRESS`,
       `cms`.`base_user`.`BIRTH`                                         AS `BIRTH`,
       `cms`.`base_user`.`DEPARTMENT_ID`                                 AS `DEPARTMENT_ID`,
       `cms`.`base_user`.`EMAIL`                                         AS `EMAIL`,
       `cms`.`base_user`.`FIRST_LOGIN`                                   AS `FIRST_LOGIN`,
       `cms`.`base_user`.`ID_CARD`                                       AS `ID_CARD`,
       `cms`.`base_user`.`JOB_ID`                                        AS `JOB_ID`,
       `cms`.`base_user`.`NAME`                                          AS `NAME`,
       `cms`.`base_user`.`ID`                                            AS `ID`,
       `cms`.`base_user`.`IS_DELETED`                                    AS `IS_DELETED`,
       `cms`.`base_user`.`NICK_NAME`                                     AS `NICK_NAME`,
       `cms`.`base_user`.`PASSWORD`                                      AS `PASSWORD`,
       `cms`.`base_user`.`PHONE`                                         AS `PHONE`,
       `cms`.`base_user`.`POSTAL_CODE`                                   AS `POSTAL_CODE`,
       `cms`.`base_user`.`REGISTER_TIME`                                 AS `REGISTER_TIME`,
       `cms`.`base_user`.`REMARKS`                                       AS `REMARKS`,
       `cms`.`base_user`.`SEX`                                           AS `SEX`,
       `cms`.`base_user`.`THEME_COLOR`                                   AS `THEME_COLOR`,
       `cms`.`base_user`.`WORK_ID`                                       AS `WORK_ID`,
       `cms`.`base_user`.`ACCOUNT`                                       AS `ACCOUNT`,
       `cms`.`base_user`.`CREATE_TIME`                                   AS `CREATE_TIME`,
       `cms`.`base_user`.`UPDATE_TIME`                                   AS `UPDATE_TIME`,
       `cms`.`base_job_position`.`NAME`                                  AS `JOB_NAME`,
       `department_getAllParentNames`(`cms`.`base_user`.`DEPARTMENT_ID`) AS `DEPARTMENT_NAME`,
       `department_getSchoolId`(`cms`.`base_user`.`DEPARTMENT_ID`)       AS `SCHOOL_ID`,
       `cms`.`base_user`.`CODE`                                          AS `CODE`
from ((`cms`.`base_user` left join `cms`.`base_department`
       on ((`cms`.`base_user`.`DEPARTMENT_ID` = `cms`.`base_department`.`ID`))) left join `cms`.`base_job_position`
      on ((`cms`.`base_user`.`JOB_ID` = `cms`.`base_job_position`.`ID`)));

-- comment on column view_base_user.ADDRESS not supported: 地址

-- comment on column view_base_user.BIRTH not supported: 出生日期

-- comment on column view_base_user.DEPARTMENT_ID not supported: 部门ID

-- comment on column view_base_user.EMAIL not supported: 电子邮件

-- comment on column view_base_user.FIRST_LOGIN not supported: 首次登陆

-- comment on column view_base_user.ID_CARD not supported: 身份证号

-- comment on column view_base_user.JOB_ID not supported: 职位ID

-- comment on column view_base_user.NAME not supported: 姓名

-- comment on column view_base_user.ID not supported: 编号

-- comment on column view_base_user.IS_DELETED not supported: 删除标记

-- comment on column view_base_user.NICK_NAME not supported: 昵称

-- comment on column view_base_user.PHONE not supported: 手机号码

-- comment on column view_base_user.POSTAL_CODE not supported: 邮政编码

-- comment on column view_base_user.REGISTER_TIME not supported: 注册时间

-- comment on column view_base_user.REMARKS not supported: 备注

-- comment on column view_base_user.SEX not supported: 性别

-- comment on column view_base_user.THEME_COLOR not supported: 主题色

-- comment on column view_base_user.WORK_ID not supported: 工号

-- comment on column view_base_user.ACCOUNT not supported: 账户

-- comment on column view_base_user.CREATE_TIME not supported: 创建时间

-- comment on column view_base_user.UPDATE_TIME not supported: 更新时间

-- comment on column view_base_user.JOB_NAME not supported: 名称

-- comment on column view_base_user.CODE not supported: 编码

